import processing.core.*; 
import processing.xml.*; 

import controlP5.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Sprouts extends PApplet {

//SPROUTS


ControlP5 controlP5;

int bkg = color(255);
PFont f;
float sproutWidth = 8;
float sproutSelectionWidth = sproutWidth*2.5f;
float thresh = 10;
float pointThresh = 5;
float checkerThresh = 10;
int numSprouts = 3;

Sprout pressed = null;
Sprout connected = null;
Sprout newSprout = null;
LineSegment currLine;
boolean drawPhase, pickNewPhase, isLegal, player, gameOver;

ArrayList<Sprout> sprouts;
ArrayList<CurveShape> curves;
ArrayList<LineSet> curveLines;


public void setup() {
  size(1000, 600);
  background(bkg);
  noStroke();
  smooth();
 controlP5 = new ControlP5(this);
 controlP5.addSlider("",1,15,width-50,height-110,30,100);
  Slider s1 = (Slider)controlP5.controller("");
  s1.setValue(numSprouts);
  s1.setColorValueLabel(color(0));
  s1.setDecimalPrecision(0);
  s1.setNumberOfTickMarks(15);
 
  f = loadFont("Helvetica-30.vlw");

  sprouts = new ArrayList<Sprout>();
  float sproutSep = width/numSprouts;
  for (int x=0; x<numSprouts; x++)
    sprouts.add(new Sprout(sproutSep*x+sproutSep/2, height/2));

  drawPhase = pickNewPhase = false;
  isLegal = true;
  player = true;
  gameOver = false;
  curves = new ArrayList<CurveShape>();
 
  curveLines = new ArrayList<LineSet>();
  
  currLine = null;
}

public void draw() {
  noStroke();
  fill(0);
  textFont(f,30);
  background(bkg);
  
  if(gameOver){
   text("Game Over!",20,40); 
   if(player){
     text("\nPlayer 2 wins!",20,40); 
   }else{
      text("\nPlayer 1 wins!",20,40);
   }
   text("\n\nPress 'r' to restart",20,40);
  }else if (drawPhase) {
    curves.get(curves.size()-1).addPos();
    currLine = curves.get(curves.size()-1).getCurrLine();
    text("Draw a line to another sprout!",20,40);
    text("Press Z to undo",width-280,40);
    if(!isLegal){
      text("Not legal!",40,200);
    }
  }
  else if (pickNewPhase) {
    PVector nearPos = curves.get(curves.size()-1).findNearest();
    newSprout = null;
    if (nearPos != null) {
      newSprout = new Sprout(nearPos.x, nearPos.y);
      newSprout.render();
    }
    text("Place a new sprout!",20,40);
    text("Press Z to undo",width-280,40);
  }else{
    
     gameOver = gameOverCheck();
     
     
   text("Pick a sprout!",20,40); 
   textFont(f,20);
   text("Use this slider to choose the number of Sprouts",width-490,height-30); 
   textFont(f,30);
   if(player){
     text("Player 1",width-150,40); 
   }else{
     text("Player 2",width-150,40); 
   }
  }
  
 

  for (Sprout s : sprouts) {
    if (s.isOver()) {
      s.over = true;
    }
    else {
      s.over = false;
    }
    s.render();
  }

  for (CurveShape c : curves) {
    c.render();
  }
  
}

public void keyPressed(){
 if(key == 'z' || key == 'Z'){
  if(drawPhase){
    drawPhase = false;
    curves.remove(curves.size()-1);
    pressed.connectors--;
    isLegal = true;
    
    System.out.println(pressed.connectors);
  }else if(pickNewPhase){
    pickNewPhase = false;
    curves.remove(curves.size()-1);
    pressed.connectors--;
    connected.connectors--;
    System.out.println(pressed.connectors + " " + connected.connectors);
  }
 }else if(key == 'r' || key == 'R'){
  setup();
 } 
  
}


public void mousePressed() {
  if (drawPhase) {
    if(isLegal){
    for (Sprout s : sprouts) {
      if (s.over && s.connectors < 3) {
        s.connectors++;
        connected = s;
        curves.get(curves.size()-1).addPos(s.pos.x, s.pos.y);
        System.out.println(s.connectors);
        drawPhase = false;
        pickNewPhase = true;
       // pressed = null;
        break;
      }
    }
    }
  }
  else if (pickNewPhase) {

    if (newSprout != null) {
      sprouts.add(newSprout);
      newSprout.connectors += 2;
      pickNewPhase = false;
      curves.get(curves.size()-1).setLines();
      player = !player;
    }
  }
  else {
    for (Sprout s : sprouts) {
      if (s.over && s.connectors < 3) {
        s.pressed = true; 
        pressed = s;
        s.connectors++;
        drawPhase = true;
        curves.add(new CurveShape(pressed.pos.x, pressed.pos.y));
        System.out.println(pressed.pos.x);
        break;
      }
    }
  }
}

public boolean gameOverCheck(){
 int lives = 3*sprouts.size();
 for(Sprout s : sprouts){
    lives -= s.connectors;
 } 
 if(lives < 2){
 return true;
 }
 return false;
}

class Sprout {
  PVector pos;
  int connectors;
  boolean over, pressed;

  Sprout(float x, float y) {
    this(x, y, 0);
    over = pressed = false;
  }

  Sprout(float x, float y, int c) {
    pos = new PVector(x, y); 
    connectors = c;
    over = pressed = false;
  }

  public boolean isOver() {
    float disX = pos.x - mouseX;
    float disY = pos.y - mouseY;
    if (sqrt(sq(disX) + sq(disY)) < sproutSelectionWidth/2 ) {
      return true;
    } 
    else {
      return false;
    }
  }


  public void render() {
    if (over) {
      fill(0, 100);
      ellipse(pos.x, pos.y, sproutSelectionWidth, sproutSelectionWidth);
    }
    fill(0);
    ellipse(pos.x, pos.y, sproutWidth, sproutWidth);
  }
}

class CurveShape {
  ArrayList<PVector> vertices;

  CurveShape(float x, float y) {
    vertices = new ArrayList<PVector>();
    vertices.add(new PVector(x, y));
  }

  public void addPos() {
    vertices.add(new PVector(mouseX, mouseY));
  }

  public void addPos(float x, float y) {
    vertices.add(new PVector(x, y));
  }

  public PVector findNearest() {
    for (PVector p : vertices) {
      if (sqrt(sq(p.x-mouseX)+sq(p.y-mouseY)) < thresh) {
        return p;
      }
    }
    return null;
  }
 
  
  public LineSegment getCurrLine(){
    return new LineSegment(vertices.get(vertices.size()-1),vertices.get(vertices.size()-2));
  }
  
  public void setLines(){
    LineSet s = new LineSet();
    s.addAll(vertices);
    curveLines.add(s);
  }

  public void render() {
    noFill();
    stroke(0);
    beginShape();
    for (PVector p : vertices) {
      curveVertex(p.x, p.y);
    }
    endShape();
    if(drawPhase){
      for(LineSet l : curveLines){
         if(l.intersects(currLine)){
           isLegal = false;
      }
      }
      
    }
  }
}


class LineSegment{
 PVector start,end;

 public LineSegment(float x, float y, float x1, float y1){
  start = new PVector(x,y);
  end = new PVector(x1,y1);
  
 }
 
  public LineSegment(PVector p1, PVector p2){
  start = new PVector(p1.x,p1.y);
  end = new PVector(p2.x,p2.y);
  
 }
 
 public boolean ccw(PVector A,PVector B,PVector C){
    return (C.y-A.y)*(B.x-A.x) > (B.y-A.y)*(C.x-A.x);
 }

 public boolean intersects(LineSegment other){
   PVector A = start;
   PVector B = end;
   PVector C = other.start;
   PVector D = other.end;
   return ccw(A,C,D) != ccw(B,C,D) && ccw(A,B,C) != ccw(A,B,D);
  
  
  }
}

class LineSet{
 ArrayList<LineSegment> segments;

 public LineSet(){
  segments = new ArrayList<LineSegment>();
  
 } 
 
 public void add(float x, float y, float x1, float y1){
  segments.add(new LineSegment(x,y,x1,y1)); 
 }
 
 public void addAll(ArrayList<PVector> v){
   PVector last = null;
   for(PVector p : v){
     if(last != null){
       add(last.x,last.y,p.x,p.y);
     }
     last = p;
     
   }
   
 }
 
 public boolean intersects(LineSegment other){
   PVector pos = other.end;
   if(pressed.pos.dist(pos) < thresh || connected.pos.dist(pos) < thresh || newSprout.pos.dist(pos) < thresh)
     return false;
  for(LineSegment l : segments){
   if(l.intersects(other)){
    return true; 
   }
  }
   return false; 
   
 }
  
  
}

public void controlEvent(ControlEvent theEvent) {
  println("got a control event from controller with id "+theEvent.controller().id());
  int value = (int)(theEvent.controller().value());
  if(value != numSprouts){
   numSprouts = value;
   setup(); 
  }
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "Sprouts" });
  }
}
